import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import TextToSpeechControls from '../components/TextToSpeechControls';
import '../styles/Story.css';

export default function Story() {
  const location = useLocation();
  const navigate = useNavigate();
  const { moral, duration, age } = location.state || {};

  const [story, setStory] = useState('');
  const [storyMoral, setStoryMoral] = useState(moral || '');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!moral || !duration || !age) {
      navigate('/prompt');
      return;
    }

    const fetchStory = async () => {
      try {
        setLoading(true);
        setError('');

        const response = await fetch(
          `/api/get-story?moral=${encodeURIComponent(moral)}&duration=${duration}&age=${age}`
        );

        if (!response.ok) {
          let errorText = 'Failed to fetch story';
          try {
            const errorBody = await response.text();
            try {
              const parsed = JSON.parse(errorBody);
              if (parsed?.error) errorText = parsed.error;
            } catch {
              console.error('Non-JSON response:', errorBody.slice(0, 100));
            }
          } catch (parseErr) {
            console.error('Unable to read error response:', parseErr);
          }
          throw new Error(errorText);
        }

        const data = await response.json();
        setStory(data.story || '');
        // Use moral from API response if available, otherwise keep the one from navigation
        if (data.moral) {
          setStoryMoral(data.moral);
        }
      } catch (err: unknown) {
        console.error('Error fetching story:', err);

        // ✅ Type-safe error handling
        if (err instanceof Error) {
          setError(err.message || 'Failed to load story');
        } else if (typeof err === 'string') {
          setError(err);
        } else {
          setError('An unknown error occurred while loading the story.');
        }
      } finally {
        setLoading(false);
      }
    };

    // Prevent double-fetch in Strict Mode or quick re-renders
    let isMounted = true;
    const timeoutId = setTimeout(() => {
      if (isMounted) fetchStory();
    }, 100);

    return () => {
      isMounted = false;
      clearTimeout(timeoutId);
    };
  }, [moral, duration, age, navigate]);

  return (
    <div className="story-page">
      <div className="page-brand" aria-label="LullabAI">
        <span className="page-brand-main">LULLAB</span>
        <span className="page-brand-ai">AI</span>
      </div>

      {/* Feedback button */}
      <button className="feedback-btn" onClick={() => navigate('/feedback')}>
        <i className="fas fa-comment-dots"></i> Feedback
      </button>


      <div className="story-card">
        {storyMoral && <div className="story-moral">Moral: {storyMoral}</div>}

        {/* Loading state */}
        {loading && <div className="loading-text">Loading your story...</div>}

        {/* Error message with retry */}
        {error && !loading && (
          <div className="error-message">
            {error}
            <button onClick={() => navigate('/prompt')} className="retry-btn">
              Try Again
            </button>
          </div>
        )}

        {/* Story text */}
        {!loading && !error && (
          <>
            <div className="story-text">{story}</div>
            <TextToSpeechControls text={story} />
          </>
        )}
      </div>

      <div className="story-actions">
        {!loading && !error && (
          <button className="btn" onClick={() => navigate('/prompt')}>
            Back to Prompt
          </button>
        )}
      </div>
    </div>
  );
}
